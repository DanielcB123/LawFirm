# Open decisions and assumptions

[Home](../README.md) · [First firm](../product/first-firm.md) · [ADR](../database/ADR-001-tenancy.md)

## Confirmed from the founder
One-stop law-firm SaaS; client consultation-to-closure portal; first real firm named Maldanado and Benitez Law; focus on construction law/litigation and personal injury; root-level Markdown directory with linked domain documents; Cursor must inspect the entire codebase first and work carefully.

## Proposed, not confirmed
Modular monolith; shared control plane; database per law firm; provider-backed payments/signatures; explicit client publication; attorney verification of legal dates; staged adoption. No codebase or hosting account was inspected in creating this blueprint.

## Resolve through audit/discovery

| Decision | Why it matters | Owner/source |
|---|---|---|
| Existing frameworks, engine, auth, deployment | Determines implementation/migration strategy | Cursor repository audit |
| Exact firm name/legal entity and jurisdiction | Contracts, configuration, legal rules | Founder and first firm |
| Fee agreements and trust practices | Ledger and distribution design | Firm attorney/accountant |
| Hosting region, residency, recovery targets | Cost, contracts, backup design | Technical owner and firm |
| Required current tools/provider exports | Migration and one-stop workflow | First-firm walkthrough |
| Client/representative/joint-client permissions | Confidentiality and portal behavior | Firm policy |
| Current schema/tenancy | Whether proposed isolation change is justified | Technical audit |
| Investment/customer commercial relationship | Does not imply legal-data access | Founder and legal advisers |
| Branding, languages, accessibility needs | Client experience | First firm |
| Research API licensing | Permitted integrated research | Provider procurement |
| Provider PCI/HIPAA/BAA obligations if applicable | Scope and contractual safeguards | Provider/firm review |

Proceed with documentation, synthetic tests, and reversible foundation work where these questions do not block correctness. Record blockers precisely rather than silently selecting production-sensitive facts.
