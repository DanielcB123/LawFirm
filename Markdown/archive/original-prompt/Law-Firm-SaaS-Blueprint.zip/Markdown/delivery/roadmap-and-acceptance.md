# Delivery sequence and acceptance

[Home](../README.md) · [Open decisions](open-decisions.md) · [Cursor prompt](../../CURSOR_PROMPT.md)

No time estimates are promised before auditing the repository and validating staff capacity.

| Phase | Concrete deliverable | Gate |
|---|---|---|
| 0: Discover | Existing architecture audit, linked Markdown, first-firm discovery, gap map | Actual code paths/evidence; known decisions separated from assumptions |
| 1: Foundation | Tenant resolution, identity, roles, matter grants, private storage, auditing | Cross-firm/matter tests, production configuration, recovery evidence |
| 2: Intake | Inquiry, consultations, conflicts review, engagement | Booking concurrency, conflicts decisions, signature evidence |
| 3: Matter/portal | Matter workspace, tasks/deadlines, documents, approved updates, messages | Complete approved client journey; publication boundary tests |
| 4: Finance | Legal billing, tokenized payments, reliable allocations | Exact calculations, webhook dedupe, refund/dispute reconciliation |
| 5: Practice depth | Construction and PI templates, evidence, settlement workflow | Attorney-approved templates and versioned decisions |
| 6: Trust production gate | Native validated trust ledger or reviewed integrated workflow | Accountant/firm policy review, three-way reconciliation, concurrency and restore evidence |
| 7: Expand | Additional firms, cost/scale validation, integrations, optional research/AI | Repeatable onboarding, isolation, provider terms, proven operations |

Real matters must not be opened on a demo-only deadline, security, or financial system. If a necessary function remains in an existing validated tool during pilot, document the handoff and keep its authoritative state clear in the application. Do not pretend it has been replaced.

## Cross-cutting acceptance suite
1. Firm A users cannot obtain Firm B records through APIs, URLs, files, search, cache, jobs, exports, analytics, or callbacks.
2. Same-firm client A cannot access client B's restricted matter or joint-client private content.
3. A blocked/conflicted prospect cannot bypass engagement review.
4. Unpublished/internal material never reaches a client serializer, preview, search, or notification.
5. Two simultaneous consultation requests do not double book.
6. Legal dates preserve source, reviewer, trigger, and time semantics.
7. Duplicate payment/signature events produce one valid effect.
8. Posted ledger entries balance; withdrawals cannot overspend; changed settlement invalidates approval.
9. Held evidence cannot expire/delete; originals and exact versions are exportable.
10. Recovery of one firm restores coherent SQL/object/financial state and honors current revocations/holds.
11. Keyboard/mobile clients can complete intake, read updates, upload documents, and pay through accessible flows.
12. Synthetic first-firm walkthrough demonstrates consultation to closure and honestly identifies unfinished capabilities.

Test domain invariants and failure boundaries, not trivial mirrors of implementation. CI should run appropriate build/static checks and meaningful integration tests using the actual database engine where its constraints matter. Keep a traceability table: requirement → implementation path → test/evidence → owner → status.
