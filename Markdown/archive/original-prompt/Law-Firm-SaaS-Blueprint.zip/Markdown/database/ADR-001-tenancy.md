# ADR-001 — firm data isolation

[Home](../README.md) · [Research](tenancy-research.md) · [Provisioning](provisioning-and-migrations.md)

**Status:** Proposed, awaiting repository and hosting validation. **Date:** 2026-10-12. **Decision owner:** Product founder and technical owner, with first-firm workflow review.

## Decision
Use one shared application release, one minimal shared control-plane database, and a separate legal-data database per law firm. All firm databases use the same versioned product schema. Separate private file namespaces and explicitly scoped jobs/search/caches accompany database isolation.

Do not select an engine or rewrite existing tenancy before auditing the repository. A functioning existing shared model requires a documented migration plan and evidence of benefit before replacement. Schema-per-firm remains an alternative if the verified engine and operations favor it. Record a superseding ADR if the evidence changes this decision.

## Rationale
Early adoption has relatively few firms. Dedicated firm data improves the clarity of ownership, logical exports, deletion workflows, and recovery compared with intermingled legal records. Database-specific credentials can limit accidental database access. Shared application code preserves SaaS economics and common delivery. More database operations and connection management are the price of this approach.

## Consequences
Provisioning, migrations, monitoring, backup/export, and credential rotation must be automated. Avoid schema customization per customer. Preserve tenant_id in domain ownership and event envelopes as defense in depth. A database per firm is not a substitute for matter-level permissions or ethical walls.

Shared servers still have shared resource and infrastructure-failure risks. On services whose PITR restores an instance/cluster, restore to an isolated environment and extract the selected firm database; do not overwrite other firms. File recovery remains a separate coordinated concern.

## Non-negotiable boundaries
A trusted tenant catalog resolves a firm to a secret reference, never a user-provided connection string. Missing/inconsistent tenant context fails closed. Cross-firm SQL joins are prohibited in ordinary request code. Operational analytics use approved minimized projections, not unrestricted joins over privileged matter data.

## Reconsideration triggers
Measured connection limits, migration fleet duration, per-firm unit cost, tenant performance concentration, contractual isolation requirements, or residency requirements. A later pool or dedicated-instance tier requires its own migration, security, restore, and cost evidence. No arbitrary tenant-count threshold guarantees when to switch.

## Adoption evidence
Repository audit complete; engine/provider selected; tenanted authorization tests pass; credential grants verified; pilot migration tested; recovery rehearsal passes; operational budget documented; first firm's confidentiality/retention/publication policy configured.
